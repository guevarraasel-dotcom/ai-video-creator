AI VIDEO CREATOR — ANDROID STARTER PROJECT
==========================================

IMPORTANT:
Ang ZIP na ito ay SOURCE PROJECT, hindi pa APK.
Para bumuo ng APK gamit ang cellphone lang, puwedeng gamitin ang GitHub Actions cloud build. Kailangan ng GitHub account at internet. Sa madaling paraan sa ibaba, gagamit ng PUBLIC repository para mabawasan ang posibilidad ng private-repository Actions limits, pero magiging nakikita ng publiko ang source code. Huwag mag-upload ng personal files, passwords, o private information.

PHONE-ONLY CLOUD BUILD
1. I-download ang AI_Video_Creator_Phone_Build_Pack.zip sa cellphone.
2. Sa browser, buksan ang https://github.com at mag-sign in / gumawa ng account kung wala ka pa.
3. Gumawa ng bagong repository. Piliin ang Public kung nais mong gamitin ang public source repo; tandaan na makikita ng publiko ang files.
4. I-upload ang buong file na AI_Video_Creator_Phone_Build_Pack.zip sa root ng repository.
5. Sa repository, piliin ang Add file > Create new file.
6. Sa filename field, ilagay ang .github/workflows/build-apk.yml
7. Buksan ang hiwalay na build-apk.yml file na kasama sa package, kopyahin ang buong laman nito, at i-paste sa GitHub editor. I-save gamit ang Commit changes.
8. Buksan ang tab na Actions. Piliin ang "Build AI Video Creator APK" at pindutin ang Run workflow kung hindi pa nagsisimula.
9. Hintaying matapos ang build. Kapag success/green, buksan ang run at hanapin ang Artifacts. I-download ang AI-Video-Creator-debug-APK.zip.
10. I-extract ang artifact ZIP sa cellphone at hanapin ang app-debug.apk.
11. I-install lamang ang APK na ikaw mismo ang nag-build mula sa sarili mong repository. Kung red/failed ang build, huwag mag-install; tingnan ang error log.

APP LIMITATIONS
- Source project ito, hindi APK.
- Kailangan ng GitHub account at internet; free usage rules at UI ay maaaring magbago.
- Ang app ay prompt/scene planner at media helper; hindi ito standalone AI video-generation engine.
- Ang video export ay WebM at nakadepende sa WebView/device support; hindi garantisadong magtagumpay sa bawat phone.
- Ang voice preview ay nakadepende sa installed Android voices. Hindi garantisadong may Tagalog voice.
- Hindi pa ito nasusubukan sa aktuwal na Android device. Subukan muna nang maingat pagkatapos mabuo.
